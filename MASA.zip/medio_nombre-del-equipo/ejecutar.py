"""
ejecutar.py - El boton de "correr todo".

    python ejecutar.py

Hace tres cosas: entrena y evalua, guarda los resultados en CSV, y arma la
aplicacion dashboard.html con esos mismos resultados.
"""
import json  # para pasar los resultados de Python a JavaScript (formato JSON)

# Traemos del cerebro solo lo que necesitamos aqui
from riesgo import CARPETA, DATOS, correr_todo, top10

# Esta linea es la que hace TODO el trabajo pesado: entrena, valida, elige
# modelo y umbral, y predice 2025. Lo demas de este archivo es mostrar y guardar.
r = correr_todo()

prueba, tabla, umbral = r["prueba"], r["metricas"], r["umbral"]  # desempacamos lo que devolvio
top = top10(prueba, mes=10)  # los diez de octubre, que es lo que pide el reto


# ---------- 1) Lo que sale en la consola ----------
print("=" * 64)
print("MOVIMIENTOS EN MASA EN SANTANDER - CATEGORIA MEDIO (datos simulados)")
print("=" * 64)

print("\nValidacion 2023-2024 (precision promedio, mas alto es mejor):")
for nombre, ap in r["validacion"].items():  # recorremos los dos candidatos
    print("  {:22s} {:.3f}".format(nombre, ap))
print("Modelo elegido: {}   |   Umbral de alerta: {:.2f}".format(r["nombre_modelo"], umbral))

print("\nPrueba 2025 (modelo vs. linea base):")
print(tabla.round(3).to_string())  # round(3): 3 decimales. to_string(): que no corte columnas

print("\nTop 10 municipios - octubre de 2025:")
print(top.round(3).to_string())
print("\nDe esos 10, registraron movimiento en masa: {}".format(int(top.hubo_mm.sum())))


# ---------- 2) Los resultados en CSV ----------
(CARPETA / "resultados").mkdir(exist_ok=True)  # crea la carpeta; exist_ok: si ya existe, no se queja

columnas = ["codigo_dane", "municipio", "anio", "mes", "probabilidad", "nivel",
            "alerta_modelo", "alerta_base", "hubo_mm"]
# index=False para que no escriba la numeracion de filas de pandas
prueba[columnas].round(4).to_csv(CARPETA / "resultados" / "predicciones_2025.csv", index=False)
# aqui si queremos el indice, porque es el puesto en el ranking (1 al 10)
top.round(4).to_csv(CARPETA / "resultados" / "top10_octubre_2025.csv", index_label="puesto")


# ---------- 3) La aplicacion: dashboard.html ----------
# La idea: plantilla.html tiene huecos (__PANEL__, __GEO__...) y aqui les metemos
# lo que el modelo ACABA de calcular. Asi el tablero nunca muestra datos viejos:
# si cambian el modelo y vuelven a correr esto, el tablero cambia solo.

# Las columnas que el tablero necesita mostrar
datos_app = prueba[["codigo_dane", "municipio", "mes", "probabilidad", "nivel", "altitud_m",
                    "lluvia_mm_mes_anterior", "mm_ultimos_12m", "hubo_mm",
                    "alerta_modelo", "alerta_base"]].round(4)

# Resumen por mes, para los KPIs del panel lateral y las graficas
mensual = {}
for mes, g in prueba.groupby("mes"):  # g = las 87 filas de ese mes
    mensual[int(mes)] = {
        "mm": int(g.hubo_mm.sum()),                              # deslizamientos reales
        "alertas": int(g.alerta_modelo.sum()),                   # alertas que lanzo el modelo
        # multiplicar las dos columnas da 1 solo cuando ambas son 1: ahi acertamos
        "aciertos": int((g.hubo_mm * g.alerta_modelo).sum()),
        "base_aciertos": int((g.hubo_mm * g.alerta_base).sum()),
    }

# Los limites de los municipios para dibujar el mapa.
# Del geojson solo sacamos lo necesario: codigo, nombre y las coordenadas.
geo = json.load(open(DATOS / "santander_municipios.geojson", encoding="utf-8"))
limites = [{"codigo": str(f["properties"]["codigo_dane"]),
            "municipio": f["properties"]["municipio"],
            "type": f["geometry"]["type"],
            "coords": f["geometry"]["coordinates"]} for f in geo["features"]]

# Datos sueltos que el tablero muestra en el encabezado y en las barras de metricas
meta = {"umbral": umbral, "modelo": r["nombre_modelo"],
        "metricas": {"Modelo": tabla.loc["Modelo"].to_dict(),
                     "base": tabla.loc["Linea base"].to_dict()}}

# separators sin espacios = JSON compacto, el archivo pesa menos.
# ensure_ascii=False para que las tildes salgan bien (Bolivar, Carcasi...).
compacto = {"ensure_ascii": False, "separators": (",", ":")}

html = (CARPETA / "plantilla.html").read_text(encoding="utf-8")  # leemos la plantilla
html = html.replace("__PANEL__", json.dumps(datos_app.to_dict("records"), **compacto))
html = html.replace("__GEO__", json.dumps(limites, **compacto))
html = html.replace("__MENSUAL__", json.dumps(mensual, **compacto))
html = html.replace("__META__", json.dumps(meta, **compacto))
(CARPETA / "dashboard.html").write_text(html, encoding="utf-8")  # y lo guardamos ya con los datos

print("\nListo: dashboard.html y resultados/")
