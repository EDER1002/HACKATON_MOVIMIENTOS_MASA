# Anticipar movimientos en masa por municipio - Santander

Prueba de seleccion UTSmart IA Challenge 2026 - **Categoria medio**

> Los datos son **simulados**. No son registros oficiales de la UNGRD ni del IDEAM.

## Integrantes
- Eder ________________
- ________________
- ________________

Equipo: `________` (renombrar la carpeta a `medio_nombre-del-equipo`)

## Como ejecutar

Python 3.10 o superior. En Linux hay que usar un entorno virtual:

```bash
python -m venv .venv
source .venv/bin/activate        # en Windows: .venv\Scripts\activate
pip install -r requirements.txt  # solo pandas y scikit-learn
python ejecutar.py               # corre todo en unos segundos
```

Eso imprime las metricas en la consola y genera:

| Salida | Que es |
|---|---|
| `dashboard.html` | **La aplicacion.** Abre con doble clic. Mapa, filtro por mes, top 10, tabla de los 87 municipios y graficas. No necesita internet ni servidor. |
| `resultados/top10_octubre_2025.csv` | Los diez municipios pedidos en el reto. |
| `resultados/predicciones_2025.csv` | Probabilidad de cada municipio en cada mes de 2025. |

Los resultados de abajo se obtuvieron con scikit-learn 1.9.1, la version fijada en
`requirements.txt`. Con otra version el umbral y las cifras pueden cambiar un poco.

## Archivos

| Archivo | Contenido |
|---|---|
| `riesgo.py` | Carga de datos, variables, linea base, modelos, umbral y metricas. |
| `ejecutar.py` | Corre todo, guarda los CSV y arma `dashboard.html`. |
| `plantilla.html` | Interfaz de la aplicacion; `ejecutar.py` le inyecta los resultados. |
| `GUIA_SUSTENTACION.md` | Guion de 4 minutos y respuestas a las preguntas del jurado. |
| `datos/` | Los tres archivos entregados en la prueba, sin modificar. |

## Que hace la solucion

1. **Solo usa lo que se conoce el dia 1 del mes.** No usa `lluvia_mm` ni `eventos_mes`
   del mes a predecir. Usa: mes, altitud, lluvia del mes anterior, eventos de los 12
   meses anteriores e historia del municipio (movimientos en masa y lluvia de meses pasados).
2. **Separa por tiempo.** Entrena 2016-2022, valida 2023-2024 (ahi elige modelo y umbral),
   reentrena 2016-2024 y evalua una sola vez en 2025.
3. **Compara con la linea base** del reto: "va a pasar lo mismo que en el mismo mes del anio anterior".

## Resultados en 2025

| | Sensibilidad | Precision | Alertas | Aciertos (de 99) |
|---|---|---|---|---|
| Modelo (gradient boosting, umbral 0.13) | 50,5 % | 19,6 % | 255 | 50 |
| Linea base | 11,1 % | 19,6 % | 56 | 11 |

**Priorizamos la sensibilidad:** no avisar de un deslizamiento que si ocurre cuesta vias,
viviendas y vidas; una alerta de mas cuesta una visita preventiva. La precision la
reportamos igual porque dice cuantas alertas puede atender el departamento.

## Limites (dicho con honestidad)

- La senal es debil: el movimiento en masa depende sobre todo de la lluvia del mismo mes,
  que no se conoce el dia 1.
- En octubre de 2025 **ninguno** de los diez municipios del top registro movimiento en masa
  (hubo 12 en 87 municipios). En el anio completo el top 10 mensual acerto 18 veces;
  elegir al azar daria unas 11.
- Sirve para priorizar monitoreo, no como pronostico exacto.
- Se uso inteligencia artificial generativa como apoyo para escribir el codigo.
