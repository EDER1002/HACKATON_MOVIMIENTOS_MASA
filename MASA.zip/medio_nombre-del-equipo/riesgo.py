"""
riesgo.py - El cerebro del proyecto.

La pregunta: el dia 1 de un mes, ¿que probabilidad hay de que este municipio
registre al menos un movimiento en masa (un deslizamiento) durante ese mes?

Regla que no se rompe en todo el archivo: solo usamos informacion que ya
existe el dia 1. Nada de lo que pasa durante el mes.
"""
from pathlib import Path  # para armar rutas de archivos que sirvan en Windows y en Linux

import pandas as pd  # pandas = tablas en Python (como Excel pero en codigo)

# De scikit-learn traemos solo las piezas que usamos:
from sklearn.compose import make_column_transformer          # transformaciones distintas a columnas distintas
from sklearn.ensemble import HistGradientBoostingClassifier  # modelo de arboles
from sklearn.linear_model import LogisticRegression          # modelo lineal (el otro candidato)
from sklearn.metrics import average_precision_score, fbeta_score, precision_score, recall_score
from sklearn.pipeline import make_pipeline                   # encadena "transformar -> entrenar" en un solo objeto
from sklearn.preprocessing import OneHotEncoder, StandardScaler

CARPETA = Path(__file__).parent  # la carpeta donde esta ESTE archivo
DATOS = CARPETA / "datos"        # ...y adentro, la carpeta datos. Asi no importa desde donde se ejecute.

# ---------------------------------------------------------------------------
# Las columnas que entran al modelo.
# Todas se conocen el dia 1. Ojo con las que NO estan aqui:
#   - lluvia_mm   : es la lluvia de TODO el mes, se sabe cuando el mes termina.
#   - eventos_mes : son las emergencias del mes, e incluyen al propio deslizamiento.
# Usarlas seria "fuga de informacion": el modelo se veria buenisimo aqui y no
# serviria en la vida real, porque el dia 1 no tendriamos esos datos.
# ---------------------------------------------------------------------------
VARIABLES = [
    "mes",                     # 1 a 12. Captura la temporada: abril-mayo y octubre-noviembre llueve mas
    "altitud_m",               # separa zona de ladera (alta) de zona baja del Magdalena Medio
    "lluvia_mm_mes_anterior",  # que tan mojado viene el suelo del mes pasado
    "eventos_12m",             # emergencias del ultimo anio: mide que tan movido es el municipio
    "mm_mismo_mes_anio_ant",   # ¿hubo deslizamiento en este mismo mes el anio pasado?
    "mm_mes_anterior",         # ¿hubo deslizamiento el mes pasado?
    "mm_ultimos_12m",          # cuantos meses con deslizamiento en el ultimo anio
    "tasa_mm_municipio",       # % historico de meses con deslizamiento en ese municipio
    "tasa_mm_municipio_mes",   # lo mismo pero solo para ese mes del calendario
    "lluvia_tipica_mes",       # cuanto suele llover ahi en esa epoca del anio
]
OBJETIVO = "hubo_mm"  # lo que queremos predecir: 1 si hubo deslizamiento, 0 si no


def cargar_datos():
    """Lee los dos CSV y los pega en una sola tabla ordenada."""
    entren = pd.read_csv(DATOS / "panel_entrenamiento_2015_2024.csv")  # 2015 a 2024
    prueba = pd.read_csv(DATOS / "panel_prueba_2025.csv")              # 2025

    # Los unimos en una sola tabla. ¿Por que? Porque enero de 2025 necesita mirar
    # a 2024 para saber "que paso el anio pasado". No es trampa: solo miramos
    # hacia atras, y el modelo nunca se ENTRENA con filas de 2025.
    panel = pd.concat([entren, prueba], ignore_index=True)  # ignore_index: renumera las filas desde 0

    # Ordenar es obligatorio antes de usar shift(): necesitamos que las filas de
    # cada municipio queden seguidas y en orden cronologico.
    return panel.sort_values(["codigo_dane", "anio", "mes"]).reset_index(drop=True)


def crear_variables(panel):
    """
    Construye la "memoria" de cada municipio: que le ha pasado antes.

    Todas las lineas de aqui llevan un shift() antes de calcular. Ese shift es
    lo que impide que el mes se vea a si mismo. Sin el, el modelo estaria
    leyendo la respuesta y nos enganiariamos solos.
    """
    p = panel.copy()  # copia, para no danar la tabla original

    # groupby("codigo_dane") = "haz lo siguiente municipio por municipio, sin mezclarlos"
    por_muni = p.groupby("codigo_dane")[OBJETIVO]

    # shift(12) = corre la columna 12 filas hacia abajo dentro del municipio.
    # Resultado: a octubre de 2025 le queda lo que paso en octubre de 2024.
    p["mm_mismo_mes_anio_ant"] = por_muni.shift(12)

    # shift(1) = lo mismo pero un mes. A octubre le queda lo de septiembre.
    p["mm_mes_anterior"] = por_muni.shift(1)

    # Leer de adentro hacia afuera:
    #   shift(1)    -> primero me corro un mes, para NO contar el mes actual
    #   rolling(12) -> abro una ventana de los 12 meses anteriores
    #   sum()       -> los sumo
    # Resultado: cuantos meses con deslizamiento hubo en el ultimo anio.
    # min_periods=1 evita que los primeros meses queden vacios: suma lo que haya.
    p["mm_ultimos_12m"] = por_muni.transform(lambda s: s.shift(1).rolling(12, min_periods=1).sum())

    # expanding() es como rolling pero sin limite: usa TODO lo anterior.
    # Con mean() da el porcentaje historico de meses con deslizamiento del municipio.
    p["tasa_mm_municipio"] = por_muni.transform(lambda s: s.shift(1).expanding().mean())

    # Ahora agrupamos por municipio Y mes del calendario. Cada grupo son todos
    # los octubres de Bucaramanga, todos los abriles de Malaga, etc.
    por_muni_mes = p.groupby(["codigo_dane", "mes"])

    # De los octubres anteriores de ese municipio, ¿en que % hubo deslizamiento?
    p["tasa_mm_municipio_mes"] = por_muni_mes[OBJETIVO].transform(lambda s: s.shift(1).expanding().mean())

    # ¿Y cuanto suele llover ahi en octubre? (promedio de los octubres anteriores)
    p["lluvia_tipica_mes"] = por_muni_mes["lluvia_mm"].transform(lambda s: s.shift(1).expanding().mean())

    return p


def linea_base(panel):
    """
    La linea base que pide el reto: "va a pasar lo mismo que el mismo mes del anio pasado".
    Es la prediccion mas simple posible, y es contra la que hay que ganar.
    """
    # fillna(0): los primeros meses no tienen anio anterior, asumimos que no paso nada.
    # astype(int): dejarlo en 0 y 1 enteros, no decimales.
    return panel["mm_mismo_mes_anio_ant"].fillna(0).astype(int)


def crear_modelos():
    """
    Los dos candidatos que vamos a comparar.

    Nota: a proposito NO usamos class_weight='balanced'. Eso infla las
    probabilidades (daba 80 % donde la frecuencia real ronda el 30 %).
    Preferimos probabilidades realistas y despues bajar el umbral de alerta.
    """
    # Candidato 1: regresion logistica. Simple y facil de explicar.
    logistica = make_pipeline(
        make_column_transformer(
            # El mes NO es "entre mas alto, mas riesgo" (diciembre no es peor que abril).
            # OneHotEncoder lo parte en 12 columnas de 0 y 1, una por mes.
            (OneHotEncoder(handle_unknown="ignore"), ["mes"]),
            # Al resto le aplicamos StandardScaler: pone todo en la misma escala,
            # porque la altitud va en miles y las tasas van entre 0 y 1.
            remainder=StandardScaler(),
        ),
        LogisticRegression(max_iter=2000),  # max_iter alto para que alcance a converger
    )

    # Candidato 2: gradient boosting. Muchos arboles pequenios, cada uno corrige
    # los errores del anterior. Ademas aguanta celdas vacias, que es justo lo que
    # tienen los primeros meses de cada municipio.
    boosting = HistGradientBoostingClassifier(
        max_depth=3,            # arboles de solo 3 niveles: cortos, para que no memoricen
        learning_rate=0.05,     # avanza de a poquito, con cuidado
        max_iter=100,           # 100 arboles en total
        l2_regularization=1.0,  # castiga modelos complicados (freno al sobreajuste)
        random_state=42,        # semilla fija: si lo corren otra vez, da lo mismo
    )
    return {"Regresion logistica": logistica, "Gradient boosting": boosting}


def metricas(y_real, y_pred):
    """
    Compara lo que paso de verdad (y_real) con lo que avisamos (y_pred).

    Sensibilidad (recall): de los deslizamientos que SI pasaron, ¿cuantos avisamos?
    Precision: de las alertas que lanzamos, ¿cuantas acertaron?
    """
    return {
        "sensibilidad": recall_score(y_real, y_pred, zero_division=0),
        "precision": precision_score(y_real, y_pred, zero_division=0),
        # F2 mezcla las dos, pero le da el DOBLE de peso a la sensibilidad,
        # porque para nosotros dejar pasar un deslizamiento es lo mas grave.
        "F2": fbeta_score(y_real, y_pred, beta=2, zero_division=0),
        "alertas": int(y_pred.sum()),                             # cuantas alertas lanzamos
        "aciertos": int(((y_pred == 1) & (y_real == 1)).sum()),   # alerta Y ocurrio: acierto
        "MM_reales": int(y_real.sum()),                           # cuantos deslizamientos hubo
    }
    # zero_division=0: si no lanzamos ninguna alerta, la precision da 0 en vez de error.


def elegir_umbral(y_real, probabilidad):
    """
    El modelo devuelve probabilidades (0.07, 0.31...). ¿A partir de cual alertamos?

    Probamos 91 umbrales y nos quedamos con el de mejor F2. Como F2 pesa doble la
    sensibilidad, el umbral que gana suele ser bajito: preferimos avisar de mas.
    """
    mejor_umbral, mejor_f2 = 0.5, -1  # arrancamos en -1 para que cualquier resultado real lo supere
    for i in range(5, 96):            # umbrales de 0.05 a 0.95
        umbral = i / 100
        # (probabilidad >= umbral) convierte las probabilidades en 0 y 1
        f2 = fbeta_score(y_real, (probabilidad >= umbral).astype(int), beta=2, zero_division=0)
        if f2 > mejor_f2:
            mejor_umbral, mejor_f2 = umbral, f2
    return mejor_umbral


def nivel(prob, umbral):
    """Traduce el numero a una palabra, para que el tablero se lea facil."""
    if prob >= 2 * umbral:  # el doble del umbral
        return "ALTO"
    if prob >= umbral:
        return "MEDIO"
    return "BAJO"


def correr_todo():
    """
    El flujo completo, de principio a fin.

    Partimos los anios POR TIEMPO, nunca al azar. Partir al azar seria usar 2024
    para predecir 2018, o sea predecir el pasado con el futuro: no tiene sentido
    y nos dejaria creyendo que el modelo es mejor de lo que es.

      2016-2022 -> entrenar los dos candidatos  (2015 se descarta: no tiene anio anterior)
      2023-2024 -> validar: aqui elegimos modelo y umbral
      2016-2024 -> reentrenar al ganador con todo lo disponible
      2025      -> prueba final, se mira UNA sola vez
    """
    panel = crear_variables(cargar_datos())  # cargar + construir la memoria historica

    entren = panel[panel.anio.between(2016, 2022)]  # between incluye los dos extremos
    valid = panel[panel.anio.between(2023, 2024)]
    todo = panel[panel.anio.between(2016, 2024)]
    prueba = panel[panel.anio == 2025].copy()  # copy() porque le vamos a agregar columnas

    # --- Paso 1: ¿cual de los dos modelos ordena mejor el riesgo? ---
    validacion, mejor_nombre, mejor_ap, prob_valid = {}, None, -1, None
    for nombre, modelo in crear_modelos().items():
        modelo.fit(entren[VARIABLES], entren[OBJETIVO])  # fit = aprende

        # predict_proba devuelve 2 columnas: prob. de 0 y prob. de 1.
        # [:, 1] toma la segunda, que es la que nos interesa.
        prob = modelo.predict_proba(valid[VARIABLES])[:, 1]

        # average_precision mide si pone los municipios de verdad riesgosos arriba,
        # sin depender de ningun umbral. Mas alto = mejor.
        ap = average_precision_score(valid[OBJETIVO], prob)
        validacion[nombre] = round(float(ap), 3)

        if ap > mejor_ap:  # nos quedamos con el mejor hasta ahora
            mejor_nombre, mejor_ap, prob_valid = nombre, ap, prob

    # --- Paso 2: el umbral tambien sale de validacion, no de 2025 ---
    umbral = elegir_umbral(valid[OBJETIVO], prob_valid)

    # --- Paso 3: reentrenamos al ganador con 2016-2024 (mas datos, mejor modelo) ---
    modelo = crear_modelos()[mejor_nombre]  # lo creamos de cero, sin lo que aprendio antes
    modelo.fit(todo[VARIABLES], todo[OBJETIVO])

    # --- Paso 4: predecimos 2025 y agregamos las columnas de salida ---
    prueba["probabilidad"] = modelo.predict_proba(prueba[VARIABLES])[:, 1]
    prueba["alerta_modelo"] = (prueba["probabilidad"] >= umbral).astype(int)  # 1 = alertamos
    prueba["alerta_base"] = linea_base(prueba)                                # lo que diria la linea base
    prueba["nivel"] = prueba["probabilidad"].apply(lambda x: nivel(x, umbral))

    # --- Paso 5: la tabla de metricas, modelo contra linea base ---
    tabla = pd.DataFrame({
        "Modelo": metricas(prueba[OBJETIVO], prueba["alerta_modelo"]),
        "Linea base": metricas(prueba[OBJETIVO], prueba["alerta_base"]),
    }).T  # .T voltea la tabla: cada fila un sistema, cada columna una metrica

    return {"nombre_modelo": mejor_nombre, "validacion": validacion,
            "umbral": umbral, "prueba": prueba, "metricas": tabla}


def top10(prueba, mes=10):
    """Los diez municipios de mayor probabilidad en un mes. Por defecto octubre (mes 10)."""
    columnas = ["municipio", "probabilidad", "nivel", "lluvia_mm_mes_anterior",
                "altitud_m", "mm_ultimos_12m", "hubo_mm"]
    # nlargest(10, "probabilidad") = los 10 de arriba, ya ordenados de mayor a menor
    t = prueba[prueba.mes == mes].nlargest(10, "probabilidad")[columnas].reset_index(drop=True)
    t.index = t.index + 1  # para que la lista empiece en 1 y no en 0
    return t
