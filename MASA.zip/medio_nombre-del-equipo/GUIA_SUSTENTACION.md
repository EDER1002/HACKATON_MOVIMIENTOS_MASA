# Guia de sustentacion (4 min + 2 de preguntas)

## Guion sugerido

| Tiempo | Quien | Que dice / muestra |
|---|---|---|
| 0:00-0:40 | Integrante 1 | El problema: decidir el dia 1 del mes donde concentrar monitoreo. Evento raro (8 % de los meses-municipio) y estacional (abril-mayo, octubre-noviembre). |
| 0:40-1:30 | Integrante 1 | Variables: descartamos `lluvia_mm` y `eventos_mes` porque no se conocen el dia 1. Creamos historia con `shift()`. (`riesgo.py`: `VARIABLES`, `crear_variables`) |
| 1:30-2:20 | Integrante 2 | En vivo: `python ejecutar.py`. Validacion por tiempo, modelo elegido, umbral 0.13. Modelo 50 % de sensibilidad contra 11 % de la linea base, con la misma precision (20 %). Priorizamos sensibilidad. |
| 2:20-3:30 | Integrante 3 | Abrir `dashboard.html`: mapa de octubre, top 10, cambiar a abril y noviembre para mostrar la estacionalidad, pestana de analisis por mes. |
| 3:30-4:00 | Integrante 3 | Honestidad: en octubre el top 10 no acerto ninguno; en el anio acerto 18 contra 11 del azar. Sirve para priorizar, no para adivinar. |

## Reparto del codigo (cada uno explica su parte)

- **Integrante 1 - datos y variables:** `cargar_datos`, `crear_variables`, `linea_base`.
- **Integrante 2 - modelo y metricas:** `crear_modelos`, `elegir_umbral`, `metricas`, `correr_todo`.
- **Integrante 3 - salida:** `top10`, `nivel`, `ejecutar.py` y las funciones de `plantilla.html` (`pintarMapa`, `barras`, `lineas`).

## Si el jurado senala una parte del codigo

**`por_muni.shift(12)`** - Dentro de cada municipio corre la columna 12 filas hacia abajo: a octubre de 2025 le pone lo que paso en octubre de 2024. Es la linea base y tambien una variable.

**`s.shift(1).rolling(12, min_periods=1).sum()`** - Primero corre un mes (para no incluir el mes actual) y despues suma los 12 anteriores: cuantos meses con movimiento en masa hubo en el ultimo anio.

**`s.shift(1).expanding().mean()`** - Promedio de todo lo anterior, sin el mes actual. Agrupado por municipio da su tasa historica; agrupado por municipio y mes da la historia de ese mes del calendario.

**Por que el `shift` siempre va antes** - Sin el, el mes entraria en su propio promedio y el modelo veria la respuesta (fuga de informacion).

**Por que unimos entrenamiento y prueba en `cargar_datos`** - Para que enero de 2025 pueda mirar a 2024. No es trampa: solo mira hacia atras, y el modelo nunca se entrena con filas de 2025.

**Por que se descarta 2015** - No tiene anio anterior, sus variables historicas quedan vacias.

**`OneHotEncoder` sobre `mes`** - En la regresion logistica el mes no es "mas es mas": abril y octubre son picos. Se convierte en 12 columnas de 0 y 1. `StandardScaler` pone las demas variables en la misma escala.

**`HistGradientBoostingClassifier`** - Muchos arboles pequenios (profundidad 3); cada uno corrige los errores del anterior. `learning_rate=0.05` hace pasos cortos; 100 arboles y `l2_regularization` evitan memorizar. Ademas acepta valores faltantes, que es lo que tienen los primeros meses de cada municipio.

**Por que no `class_weight='balanced'`** - Infla las probabilidades (daba 80 % donde la frecuencia real ronda el 30 %). Preferimos probabilidades realistas y bajar el umbral.

**`average_precision_score`** - Mide que tan bien el modelo ordena de mayor a menor riesgo, sin depender de un umbral. Con ella elegimos entre los dos modelos en 2023-2024.

**`elegir_umbral` y F2** - Prueba umbrales de 0.05 a 0.95 en validacion y se queda con el de mejor F2, que combina precision y sensibilidad pesando el doble la sensibilidad. Salio 0.13: se alerta cuando la probabilidad supera 13 %, bastante por encima de la frecuencia normal (8 %).

**`predict_proba(...)[:, 1]`** - Devuelve dos columnas (probabilidad de 0 y de 1); tomamos la de 1.

**`nivel`** - MEDIO si supera el umbral, ALTO si supera el doble del umbral.

**`html.replace("__PANEL__", ...)` en `ejecutar.py`** - La aplicacion no trae datos guardados: `plantilla.html` tiene huecos y `ejecutar.py` les mete lo que el modelo acaba de calcular. Si cambia el modelo, cambia el tablero.

**`pintarMapa` en `plantilla.html`** - Lee el geojson ya inyectado, proyecta cada par (longitud, latitud) a pixeles con una escala lineal, dibuja un `<polygon>` por municipio coloreado con su probabilidad y pone un punto verde donde si hubo movimiento en masa.

**`barras` y `lineas`** - Dibujamos las graficas como SVG a mano, sin libreria, para que la aplicacion funcione sin internet el dia de la prueba.

## Metricas, en palabras

- **Sensibilidad (recall):** de los 99 movimientos en masa reales de 2025, cuantos avisamos. Modelo 50, linea base 11.
- **Precision:** de las alertas emitidas, cuantas acertaron. Modelo 50 de 255, linea base 11 de 56 (20 % en ambos).
- **Por que sensibilidad:** el falso negativo es una comunidad sin aviso; el falso positivo es una visita preventiva. Pero la precision limita cuantas alertas se pueden atender, por eso se reporta siempre.
- **Costo que hay que reconocer:** el modelo emite mas de cuatro veces las alertas de la linea base (255 contra 56, unas 21 por mes).

## Las tres preguntas fijas

**1. Explicar una porcion del codigo** - ver arriba.

**2. Que decidimos no construir y por que**
- No usamos la lluvia del mismo mes ni `eventos_mes`: no se conocen el dia 1.
- No usamos XGBoost ni redes neuronales: con unas 9.000 filas y senal debil no aportan y son mas dificiles de explicar.
- No usamos librerias de mapas ni de graficas (folium, Chart.js): necesitan internet; dibujamos el SVG nosotros.
- No trajimos datos externos (pronostico de lluvia, pendiente, geologia): la regla pide solo la carpeta `datos`.

**3. Que hariamos con dos horas mas**
- Primero: validacion con varios cortes de tiempo (entrenar hasta 2019 y probar 2020, hasta 2020 y probar 2021, etc.) para saber si el resultado es estable; hoy depende de un solo corte.
- Variables de vecindad: si llovio o hubo eventos en los municipios vecinos (con el geojson).
- Lluvia acumulada de 2 y 3 meses, y diferencia frente a la lluvia tipica.
- Revisar la calibracion: si cuando el modelo dice 30 % ocurre cerca del 30 % de las veces.

## Preguntas probables

**Por que el top 10 de octubre no acerto ninguno** - En octubre hubo 12 eventos en 87 municipios y dependen de la lluvia de ese mes, que no conocemos el dia 1. La probabilidad mas alta fue 31 %: el modelo mismo dice que lo mas probable es que no pase. Aun asi es mala suerte en ese mes; en el anio el top 10 acierta mas que el azar (18 contra 11).

**Entonces para que sirve** - Detecta mas de cuatro veces los eventos de la linea base (50 contra 11) con la misma precision, y da una lista ordenada para repartir recursos limitados.

**Hay sobreajuste** - El modelo y el umbral se eligieron en 2023-2024 y 2025 se miro una sola vez. La precision promedio no cayo al pasar a datos nuevos: 0,16 en validacion y 0,21 en prueba.

**Por que cambian un poco los numeros entre computadores** - Dependen de la version de scikit-learn. Por eso `requirements.txt` fija la 1.9.1.

**Usaron IA** - Si, como apoyo para escribir el codigo; cada integrante lo estudio y lo puede explicar.
